--
-- PostgreSQL database dump
--

\restrict IYwErbhMK03dy7WxOVYxkf4J7hR1S2JWGwZEw1hjO3fdjMLLSvqBHXx2X3Qiyo0

-- Dumped from database version 17.6 (Debian 17.6-1.pgdg13+1)
-- Dumped by pg_dump version 17.6 (Ubuntu 17.6-2.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id integer NOT NULL,
    owner character varying(100),
    balance double precision
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounts_id_seq OWNER TO postgres;

--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: idempotency_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.idempotency_keys (
    key character varying(64) NOT NULL,
    request_hash character varying(128) NOT NULL,
    response_body text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.idempotency_keys OWNER TO postgres;

--
-- Name: pix_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pix_transactions (
    id integer NOT NULL,
    from_account_id integer NOT NULL,
    to_account_id integer NOT NULL,
    amount double precision NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.pix_transactions OWNER TO postgres;

--
-- Name: pix_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pix_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pix_transactions_id_seq OWNER TO postgres;

--
-- Name: pix_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pix_transactions_id_seq OWNED BY public.pix_transactions.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    tipo character varying(32) NOT NULL,
    valor numeric(12,2) NOT NULL,
    referencia character varying(255),
    criado_em timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transactions_id_seq OWNER TO postgres;

--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(255),
    password_hash character varying(255) NOT NULL,
    type character varying(20)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: pix_transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pix_transactions ALTER COLUMN id SET DEFAULT nextval('public.pix_transactions_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, owner, balance) FROM stdin;
1	mock:1	995.56
2	mock:2	104.44
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
a0e30676ce5e
\.


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.idempotency_keys (key, request_hash, response_body, created_at) FROM stdin;
pix-prod-1759759851	b91885be7bc41ba293b1bd7d1b9a037cd1ecbf8f2765b46def85ab74b43e854f	{"status": "ok", "debit_tx_id": 172, "credit_tx_id": 173, "balance_from": 995.56, "balance_to": 104.44}	2025-10-06 14:10:51.993367+00
\.


--
-- Data for Name: pix_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pix_transactions (id, from_account_id, to_account_id, amount, created_at) FROM stdin;
1	1	2	4.44	2025-10-06 14:10:51.993367+00
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (id, user_id, tipo, valor, referencia, criado_em) FROM stdin;
1	2	deposito	25.00		2025-09-18 22:27:36.243265+00
2	2	deposito	100.50		2025-09-19 00:12:50.510704+00
3	2	deposito	100.50		2025-09-19 00:18:53.195073+00
4	2	deposito	100.50		2025-09-19 00:23:00.930658+00
5	2	deposito	100.50		2025-09-19 00:27:10.005121+00
6	2	deposito	100.50		2025-09-19 00:36:29.067729+00
7	2	deposito	100.50		2025-09-19 00:40:14.315357+00
8	3	deposito	25.50	smoke prod	2025-09-19 21:59:35.287859+00
9	3	saque	5.00	smoke saque	2025-09-19 22:25:20.459872+00
10	3	deposito	10.02	round test	2025-09-19 23:32:56.20759+00
11	3	saque	999999.00	teste overdraft	2025-09-20 01:00:47.185986+00
12	6	deposito	10.00	via UI	2025-09-23 00:38:26.322467+00
13	6	deposito	10.00	via UI	2025-09-23 00:38:26.865144+00
14	6	deposito	10.00	via UI	2025-09-23 00:38:27.214619+00
15	6	saque	10.00	via UI	2025-09-23 00:38:30.162047+00
16	6	saque	10.00	via UI	2025-09-23 00:38:30.350421+00
17	6	saque	10.00	via UI	2025-09-23 00:38:30.520763+00
18	6	deposito	10.00	via UI	2025-09-23 01:11:47.464855+00
19	6	deposito	10.00	via UI	2025-09-23 01:11:47.744177+00
20	6	saque	10.00	via UI	2025-09-23 01:11:49.511555+00
21	6	saque	10.00	via UI	2025-09-23 01:11:49.567742+00
22	6	deposito	10.00	via UI	2025-09-23 01:11:52.825664+00
23	6	deposito	10.00	via UI	2025-09-23 01:11:54.429681+00
24	6	saque	10.00	via UI	2025-09-23 01:11:56.238689+00
25	6	deposito	10.00	via UI	2025-09-23 01:23:42.648102+00
26	6	saque	10.00	via UI	2025-09-23 01:23:43.910034+00
27	6	saque	10.00	via UI	2025-09-23 01:23:44.904322+00
28	6	deposito	10.00	via UI	2025-09-23 01:51:48.072697+00
29	6	saque	10.00	via UI	2025-09-23 01:51:49.666323+00
30	6	deposito	10.00	via UI	2025-09-23 01:58:34.267424+00
31	6	saque	10.00	via UI	2025-09-23 01:58:36.34763+00
32	6	deposito	10.00	via UI	2025-09-23 02:05:36.041587+00
33	6	saque	10.00	via UI	2025-09-23 02:05:40.008341+00
34	6	deposito	10.00	via UI	2025-09-23 02:14:45.944533+00
35	6	saque	10.00	via UI	2025-09-23 02:14:48.469637+00
36	6	deposito	10.00	via UI	2025-09-23 02:35:57.593165+00
37	6	deposito	10.00	via UI	2025-09-23 02:36:02.074431+00
38	6	saque	10.00	via UI	2025-09-23 02:36:05.347859+00
39	6	saque	10.00	via UI	2025-09-23 02:36:07.636189+00
40	6	deposito	10.00	via UI	2025-09-23 02:43:27.289909+00
41	6	saque	10.00	via UI	2025-09-23 02:43:29.462956+00
42	6	deposito	10.00	via UI	2025-09-23 02:56:45.279374+00
43	6	deposito	10.00	via UI	2025-09-23 02:56:46.042566+00
44	6	deposito	10.00	via UI	2025-09-23 02:56:46.254934+00
45	6	deposito	10.00	via UI	2025-09-23 02:56:46.447809+00
46	6	saque	10.00	via UI	2025-09-23 02:56:48.150704+00
47	6	saque	10.00	via UI	2025-09-23 02:56:49.263095+00
48	6	saque	10.00	via UI	2025-09-23 02:56:50.343493+00
49	6	saque	10.00	via UI	2025-09-23 02:56:51.415747+00
50	6	deposito	10.00	via UI	2025-09-24 00:47:33.931525+00
51	6	saque	10.00	via UI	2025-09-24 00:47:35.034038+00
52	6	deposito	10.00	via UI	2025-09-24 00:58:41.864203+00
53	6	saque	10.00	via UI	2025-09-24 02:27:03.36725+00
54	6	deposito	10.00	via UI	2025-09-24 02:28:46.127372+00
55	6	saque	10.00	via UI	2025-09-24 02:28:47.563416+00
56	14	deposito	100.50	depósito de teste	2025-09-30 13:03:06.381026+00
57	14	deposito	100.50	depósito de teste	2025-09-30 13:04:25.355896+00
58	18	deposito	37.50	smoke-test 2025-10-02T12:29:00Z	2025-10-02 12:29:04.352409+00
59	18	deposito	37.50	smoke-test 2025-10-02T12:34:40Z	2025-10-02 12:34:44.008902+00
60	18	deposito	37.50	smoke-test 2025-10-02T12:38:51Z	2025-10-02 12:38:54.906938+00
61	18	saque	5.00	smoke-withdraw 2025-10-02T12:38:56Z	2025-10-02 12:38:56.591488+00
62	18	deposito	37.50	smoke-test 2025-10-02T12:38:57Z	2025-10-02 12:39:00.913572+00
63	18	saque	7.25	smoke-withdraw 2025-10-02T12:39:02Z	2025-10-02 12:39:02.600974+00
64	18	deposito	37.50	smoke-test 2025-10-02T12:43:43Z	2025-10-02 12:43:44.491848+00
65	18	saque	5.00	smoke-withdraw 2025-10-02T12:43:44Z	2025-10-02 12:43:44.776633+00
66	18	deposito	37.50	smoke-test 2025-10-02T12:56:07Z	2025-10-02 12:56:11.667982+00
67	18	saque	5.00	smoke-withdraw 2025-10-02T12:56:12Z	2025-10-02 12:56:13.424588+00
68	18	deposito	37.50	smoke-test 2025-10-02T12:58:27Z	2025-10-02 12:58:28.161403+00
69	18	saque	5.00	smoke-withdraw 2025-10-02T12:58:28Z	2025-10-02 12:58:28.641397+00
70	18	deposito	37.50	smoke-test 2025-10-02T13:32:14Z	2025-10-02 13:32:16.338558+00
71	18	saque	5.00	smoke-withdraw 2025-10-02T13:32:16Z	2025-10-02 13:32:17.23866+00
72	18	deposito	37.50	smoke-test 2025-10-02T13:44:48Z	2025-10-02 13:44:50.422214+00
73	18	saque	5.00	smoke-withdraw 2025-10-02T13:44:50Z	2025-10-02 13:44:50.822935+00
74	18	deposito	37.50	smoke-test 2025-10-02T13:47:49Z	2025-10-02 13:47:50.708313+00
75	18	saque	5.00	smoke-withdraw 2025-10-02T13:47:50Z	2025-10-02 13:47:51.023259+00
76	18	deposito	37.50	smoke-test 2025-10-02T13:48:04Z	2025-10-02 13:48:05.163679+00
77	18	saque	5.00	smoke-withdraw 2025-10-02T13:48:05Z	2025-10-02 13:48:05.479681+00
78	18	deposito	37.50	smoke-test 2025-10-02T13:53:05Z	2025-10-02 13:53:06.561987+00
79	18	saque	5.00	smoke-withdraw 2025-10-02T13:53:06Z	2025-10-02 13:53:06.849754+00
80	18	deposito	37.50	smoke-test 2025-10-02T13:57:52Z	2025-10-02 13:57:53.544385+00
81	18	saque	5.00	smoke-withdraw 2025-10-02T13:57:53Z	2025-10-02 13:57:54.014435+00
82	18	deposito	37.50	smoke-test 2025-10-02T16:10:27Z	2025-10-02 16:10:31.675282+00
83	18	saque	5.00	smoke-withdraw 2025-10-02T16:10:32Z	2025-10-02 16:10:33.343707+00
84	18	deposito	37.50	smoke-test 2025-10-02T16:10:33Z	2025-10-02 16:10:37.845178+00
85	18	saque	5.00	smoke-withdraw 2025-10-02T16:10:39Z	2025-10-02 16:10:39.536115+00
86	18	deposito	37.50	smoke-test 2025-10-02T16:17:42Z	2025-10-02 16:17:46.109185+00
87	18	saque	5.00	smoke-withdraw 2025-10-02T16:17:47Z	2025-10-02 16:17:47.762927+00
88	18	deposito	37.50	smoke-test 2025-10-02T16:20:04Z	2025-10-02 16:20:08.064704+00
89	18	saque	5.00	smoke-withdraw 2025-10-02T16:20:09Z	2025-10-02 16:20:09.71222+00
90	18	deposito	37.50	smoke-test 2025-10-02T17:10:31Z	2025-10-02 17:10:33.52458+00
91	18	saque	5.00	smoke-withdraw 2025-10-02T17:10:34Z	2025-10-02 17:10:34.235208+00
92	18	deposito	37.50	smoke-test 2025-10-02T17:11:24Z	2025-10-02 17:11:25.99702+00
93	18	saque	5.00	smoke-withdraw 2025-10-02T17:11:26Z	2025-10-02 17:11:26.476038+00
94	18	deposito	37.50	smoke-test 2025-10-02T17:12:11Z	2025-10-02 17:12:12.437083+00
95	18	saque	5.00	smoke-withdraw 2025-10-02T17:12:12Z	2025-10-02 17:12:12.728042+00
96	18	deposito	37.50	smoke-test 2025-10-02T17:13:03Z	2025-10-02 17:13:03.928503+00
97	18	saque	5.00	smoke-withdraw 2025-10-02T17:13:04Z	2025-10-02 17:13:04.21799+00
98	18	deposito	37.50	smoke-test 2025-10-02T17:16:10Z	2025-10-02 17:16:11.756253+00
99	18	saque	5.00	smoke-withdraw 2025-10-02T17:16:12Z	2025-10-02 17:16:12.194189+00
100	18	deposito	37.50	smoke-test 2025-10-02T17:16:33Z	2025-10-02 17:16:34.125658+00
101	18	saque	5.00	smoke-withdraw 2025-10-02T17:16:34Z	2025-10-02 17:16:34.386627+00
102	18	deposito	37.50	smoke-test 2025-10-02T17:17:01Z	2025-10-02 17:17:02.400033+00
103	18	saque	5.00	smoke-withdraw 2025-10-02T17:17:02Z	2025-10-02 17:17:02.739164+00
104	18	deposito	37.50	smoke-test 2025-10-02T17:17:22Z	2025-10-02 17:17:23.403277+00
105	18	saque	5.00	smoke-withdraw 2025-10-02T17:17:23Z	2025-10-02 17:17:23.660718+00
106	18	deposito	37.50	smoke-test 2025-10-02T18:24:14Z	2025-10-02 18:24:15.782085+00
107	18	saque	5.00	smoke-withdraw 2025-10-02T18:24:16Z	2025-10-02 18:24:16.21388+00
108	18	deposito	37.50	smoke-test 2025-10-02T20:20:31Z	2025-10-02 20:20:32.561312+00
109	18	saque	5.00	smoke-withdraw 2025-10-02T20:20:32Z	2025-10-02 20:20:32.800466+00
110	18	deposito	37.50	smoke-test 2025-10-02T20:24:00Z	2025-10-02 20:24:01.769913+00
111	18	saque	5.00	smoke-withdraw 2025-10-02T20:24:01Z	2025-10-02 20:24:01.966262+00
112	18	deposito	37.50	smoke-test 2025-10-02T21:06:36Z	2025-10-02 21:06:38.131369+00
113	18	saque	5.00	smoke-withdraw 2025-10-02T21:06:38Z	2025-10-02 21:06:38.78074+00
114	18	deposito	37.50	smoke-test 2025-10-02T21:14:45Z	2025-10-02 21:14:46.589005+00
115	18	saque	5.00	smoke-withdraw 2025-10-02T21:14:47Z	2025-10-02 21:14:47.128694+00
116	18	deposito	37.50	smoke-test 2025-10-02T21:49:00Z	2025-10-02 21:49:01.999986+00
117	18	saque	5.00	smoke-withdraw 2025-10-02T21:49:02Z	2025-10-02 21:49:02.451036+00
118	18	deposito	37.50	smoke-test 2025-10-03T01:15:18Z	2025-10-03 01:15:20.437584+00
119	18	saque	5.00	smoke-withdraw 2025-10-03T01:15:20Z	2025-10-03 01:15:21.078943+00
120	18	deposito	37.50	smoke-test 2025-10-03T01:41:10Z	2025-10-03 01:41:12.251426+00
121	18	saque	5.00	smoke-withdraw 2025-10-03T01:41:12Z	2025-10-03 01:41:12.978499+00
122	18	deposito	37.50	smoke-test 2025-10-03T02:03:12Z	2025-10-03 02:03:13.355058+00
123	18	saque	5.00	smoke-withdraw 2025-10-03T02:03:13Z	2025-10-03 02:03:13.745737+00
124	18	deposito	37.50	smoke-test 2025-10-03T02:11:02Z	2025-10-03 02:11:03.95611+00
125	18	saque	5.00	smoke-withdraw 2025-10-03T02:11:04Z	2025-10-03 02:11:04.600569+00
126	18	deposito	37.50	smoke-test 2025-10-03T02:38:30Z	2025-10-03 02:38:31.296009+00
127	18	saque	5.00	smoke-withdraw 2025-10-03T02:38:31Z	2025-10-03 02:38:31.604334+00
128	18	deposito	37.50	smoke-test 2025-10-03T02:39:04Z	2025-10-03 02:39:06.187932+00
129	18	saque	5.00	smoke-withdraw 2025-10-03T02:39:06Z	2025-10-03 02:39:06.570384+00
130	18	deposito	37.50	smoke-test 2025-10-03T03:12:32Z	2025-10-03 03:12:33.62326+00
131	18	saque	5.00	smoke-withdraw 2025-10-03T03:12:33Z	2025-10-03 03:12:34.085714+00
132	18	deposito	37.50	smoke-test 2025-10-03T03:24:49Z	2025-10-03 03:24:50.672015+00
133	18	saque	5.00	smoke-withdraw 2025-10-03T03:24:51Z	2025-10-03 03:24:51.176036+00
134	18	deposito	37.50	smoke-test 2025-10-03T03:27:40Z	2025-10-03 03:27:41.904186+00
135	18	saque	5.00	smoke-withdraw 2025-10-03T03:27:42Z	2025-10-03 03:27:42.407961+00
136	18	deposito	37.50	smoke-test 2025-10-03T03:50:57Z	2025-10-03 03:50:58.586469+00
137	18	saque	5.00	smoke-withdraw 2025-10-03T03:50:59Z	2025-10-03 03:50:59.175675+00
138	18	deposito	37.50	smoke-test 2025-10-03T03:51:36Z	2025-10-03 03:51:38.65488+00
139	18	saque	5.00	smoke-withdraw 2025-10-03T03:51:39Z	2025-10-03 03:51:39.19553+00
140	18	deposito	37.50	smoke-test 2025-10-03T06:25:10Z	2025-10-03 06:25:11.457123+00
141	18	saque	5.00	smoke-withdraw 2025-10-03T06:25:11Z	2025-10-03 06:25:12.065882+00
142	18	deposito	37.50	smoke-test 2025-10-03T09:17:14Z	2025-10-03 09:17:15.892208+00
143	18	saque	5.00	smoke-withdraw 2025-10-03T09:17:16Z	2025-10-03 09:17:16.488331+00
144	18	deposito	37.50	smoke-test 2025-10-03T12:34:41Z	2025-10-03 12:34:42.725556+00
145	18	saque	5.00	smoke-withdraw 2025-10-03T12:34:43Z	2025-10-03 12:34:43.21261+00
146	18	deposito	37.50	smoke-test 2025-10-03T13:08:28Z	2025-10-03 13:08:29.342168+00
147	18	saque	5.00	smoke-withdraw 2025-10-03T13:08:29Z	2025-10-03 13:08:29.540884+00
148	18	deposito	37.50	smoke-test 2025-10-03T13:10:24Z	2025-10-03 13:10:25.488139+00
149	18	saque	5.00	smoke-withdraw 2025-10-03T13:10:25Z	2025-10-03 13:10:25.816538+00
150	18	deposito	37.50	smoke-test 2025-10-03T13:21:46Z	2025-10-03 13:21:48.377056+00
151	18	saque	5.00	smoke-withdraw 2025-10-03T13:21:48Z	2025-10-03 13:21:49.012357+00
152	18	deposito	37.50	smoke-test 2025-10-03T13:22:37Z	2025-10-03 13:22:38.428835+00
153	18	saque	5.00	smoke-withdraw 2025-10-03T13:22:38Z	2025-10-03 13:22:38.708927+00
154	18	deposito	37.50	smoke-test 2025-10-03T13:26:47Z	2025-10-03 13:26:48.468428+00
155	18	saque	5.00	smoke-withdraw 2025-10-03T13:26:48Z	2025-10-03 13:26:48.795242+00
156	18	deposito	37.50	smoke-test 2025-10-03T13:27:21Z	2025-10-03 13:27:22.961976+00
157	18	saque	5.00	smoke-withdraw 2025-10-03T13:27:23Z	2025-10-03 13:27:23.610421+00
158	18	deposito	37.50	smoke-test 2025-10-03T13:32:44Z	2025-10-03 13:32:45.065269+00
159	18	saque	5.00	smoke-withdraw 2025-10-03T13:32:45Z	2025-10-03 13:32:45.389902+00
160	18	deposito	37.50	smoke-test 2025-10-03T15:16:56Z	2025-10-03 15:16:57.517747+00
161	18	saque	5.00	smoke-withdraw 2025-10-03T15:16:57Z	2025-10-03 15:16:57.994056+00
162	18	deposito	37.50	smoke-test 2025-10-03T18:23:52Z	2025-10-03 18:23:53.440591+00
163	18	saque	5.00	smoke-withdraw 2025-10-03T18:23:53Z	2025-10-03 18:23:53.719908+00
164	18	deposito	37.50	smoke-test 2025-10-03T21:14:14Z	2025-10-03 21:14:15.853056+00
165	18	saque	5.00	smoke-withdraw 2025-10-03T21:14:16Z	2025-10-03 21:14:16.361943+00
166	18	deposito	37.50	smoke-test 2025-10-04T00:30:20Z	2025-10-04 00:30:22.069201+00
167	18	saque	5.00	smoke-withdraw 2025-10-04T00:30:22Z	2025-10-04 00:30:22.731602+00
168	18	deposito	37.50	smoke-test 2025-10-04T00:34:21Z	2025-10-04 00:34:22.379987+00
169	18	saque	5.00	smoke-withdraw 2025-10-04T00:34:22Z	2025-10-04 00:34:22.762259+00
170	18	deposito	37.50	smoke-test 2025-10-04T01:13:12Z	2025-10-04 01:13:13.46252+00
171	18	saque	5.00	smoke-withdraw 2025-10-04T01:13:13Z	2025-10-04 01:13:13.833244+00
172	1	PIX_MOCK_DEBIT	4.44	to:2	2025-10-06 14:10:51.993367+00
173	2	PIX_MOCK_CREDIT	4.44	from:1	2025-10-06 14:10:51.993367+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, full_name, password_hash, type) FROM stdin;
1	primeiro@exemplo.com	Primeiro User	$2b$12$zMiILLzPJEPIG19gUyC7EetUnZSO8TXK4XX4L1GPWNevEUI7nT8ci	\N
2	dilsonpereira231@gmail.com	\N	$2b$12$TLjUAvu8laUPlMjYUJzvlezpfKslniPXLW9ipOoFDn7NClNTNKz2m	\N
3	qa.prod@dilswallet.io	\N	$2b$12$u8PD1BULYLUfKMEZOL9E2OCZcGyNj7Wvo6MZkiR2Pl0P7ymnJM9SW	\N
4	smoke+1758569541@dilswallet.com	\N	$pbkdf2-sha256$29000$XgtByDlHaO0dgzAmZExJ6Q$5/QNafB5nWXpxGGMBmJNQqnsWLu8MzTDobqow1wTM08	\N
5	smoke1758569984@dilswallet.com	\N	$pbkdf2-sha256$29000$Sel9LwVAqLUWwhgjJMT43w$WeOtVyRfg9pLFc.Zaia7Xk5gjhy44ydkpchxaxLARfk	\N
6	dilson1758586729@dilswallet.com	\N	$pbkdf2-sha256$29000$zVkLobR2bq11ztm7N8Y4Zw$qBHYUeuqtV0XrJGFunPhxynxVYsdy4x8bmE5Vk.dFTk	\N
7	teste9@dilswallet.com	\N	$pbkdf2-sha256$29000$KWUspZRybo2RktI653xvLQ$NyAx452z0uU5NUYfbd7DHzx7s381kajHJ7FkMJLWQZE	\N
8	smoke1758676518@dilswallet.com	\N	$pbkdf2-sha256$29000$BoBwrlXqvbe29t57DyEEgA$0DhsfpOXIUfLuCfQGsCzjDwg2UbjC.YGSx.1ViLAeTA	\N
9	smoke1758678576@dilswallet.com	\N	$pbkdf2-sha256$29000$TIlx7l0LIcQYg3DO2VurVQ$TBOaywWxekuPZ9VujUOQfZv4rVhzveiTwYdq73I.mHI	\N
10	smoke1758679102@dilswallet.com	\N	$pbkdf2-sha256$29000$ds55T8k5J.T83zuHEMK4Fw$4Zl/QGRIbdIXZcAw.xbxqKrp5U2HY9iGXIf0SZTqPRs	\N
11	smoke1758680560@dilswallet.com	\N	$pbkdf2-sha256$29000$4fzf./9/jxFijFGK0brXOg$tT.YmD7WUeX9NQg1flVfsFGMxd1fPqgPi1x5vrGkyuQ	\N
12	cli1759211622@example.com	\N	$pbkdf2-sha256$29000$RQhhzHnPuZfSuhdiLCUk5A$cWUaeAwy7Mdjd82EGJQLrPLqibxxvJxOm5aAQcVMxaI	\N
13	cli1759236895@example.com	\N	$pbkdf2-sha256$29000$8j4nBMC49x6DsFYqxThnrA$66fuH3TTSVVYwffS9jAvWPatDnBK/jxT7B6awyeEEM8	\N
14	cli1759236983@example.com	\N	$pbkdf2-sha256$29000$uNdaq/W.F8JYK8XYG.O8lw$z/YJlPFnG7Y/8KItKTvFru44/PjX85fvpP22CHUSk5I	\N
15	smoke1759327202@dilswallet.com	\N	$pbkdf2-sha256$29000$BOCc897buzeGkHKuFeJ8Lw$gyHHLZTNXxkG2hb/FAeO5dOiPAo5ZUHrLcdrgRdsw2g	\N
16	smoke1759355218@dilswallet.com	\N	$pbkdf2-sha256$29000$vzdG6H0PQYgR4nyPMYYwpg$KLj6mwaDOB2.jrn5JXIPxRr/q3ruVierWu8aNrf6Lm0	\N
17	teste10@dilswallet.com	\N	$pbkdf2-sha256$29000$7J3TupcSolSq1fpfq/UeQw$Dh0x/.efEG9Q2qwpNlNaHSxX.p9WMnXZKAqJ49goIz0	\N
18	smoke@dilswallet.com	\N	$pbkdf2-sha256$29000$n/Pee08pxVgrZewdQyiFsA$l7ZgqpZ8ab.ZUQH0HTGvp3gqRZg5ng9p7WJ3w6G9hqw	\N
\.


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_id_seq', 1, false);


--
-- Name: pix_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pix_transactions_id_seq', 1, true);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transactions_id_seq', 173, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 18, true);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (key);


--
-- Name: pix_transactions pix_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pix_transactions
    ADD CONSTRAINT pix_transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_accounts_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_accounts_id ON public.accounts USING btree (id);


--
-- Name: ix_pix_transactions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_pix_transactions_id ON public.pix_transactions USING btree (id);


--
-- Name: ix_transactions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_transactions_id ON public.transactions USING btree (id);


--
-- Name: ix_transactions_tipo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_transactions_tipo ON public.transactions USING btree (tipo);


--
-- Name: ix_transactions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_transactions_user_id ON public.transactions USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: pix_transactions pix_transactions_from_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pix_transactions
    ADD CONSTRAINT pix_transactions_from_account_id_fkey FOREIGN KEY (from_account_id) REFERENCES public.accounts(id);


--
-- Name: pix_transactions pix_transactions_to_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pix_transactions
    ADD CONSTRAINT pix_transactions_to_account_id_fkey FOREIGN KEY (to_account_id) REFERENCES public.accounts(id);


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict IYwErbhMK03dy7WxOVYxkf4J7hR1S2JWGwZEw1hjO3fdjMLLSvqBHXx2X3Qiyo0

