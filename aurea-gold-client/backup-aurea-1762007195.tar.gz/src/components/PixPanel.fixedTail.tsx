      {/* rodapé compacto do painel PIX */}
      <footer className="text-xs text-zinc-500 text-center mt-6 opacity-70">
        <div>Aurea Gold • PIX interno de teste</div>
        <div>Ambiente simulado — não é banco comercial</div>
      </footer>
    </main>
  );
}

export default PixPanel;
