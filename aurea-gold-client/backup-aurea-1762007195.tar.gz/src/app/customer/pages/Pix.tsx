import React from "react";
import PixPanel from "../components/PixPanel";
export default function Pix() { return <PixPanel />; }
