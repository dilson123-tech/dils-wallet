import React, { useEffect, useState } from "react";

type Ultimas24h = { entradas: number; saidas: number; qtd: number; };
type Summary = {
  saldo_atual: number;
  entradas_total: number;
  saidas_total: number;
  ultimas_24h: Ultimas24h;
};

const API_BASE =
  (import.meta as any)?.env?.VITE_API_BASE?.toString() ||
  "http://127.0.0.1:8080";

function beepOk() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination); o.type = "sine"; o.frequency.value = 880;
    g.gain.setValueAtTime(0.0001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.18);
    o.start(); o.stop(ctx.currentTime + 0.2);
  } catch {}
}

export default function PixAISummary() {
  const [data, setData] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [answer, setAnswer] = useState<string>("");

  async function loadSummary() {
    setLoading(true); setErr(null);
    try {
      const r = await fetch(`${API_BASE}/api/v1/ai/summary`);
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const js: Summary = await r.json();
      setData(js);
      beepOk();
    } catch (e: any) {
      setErr(e?.message || "Falha ao consultar IA");
    } finally {
      setLoading(false);
    }
  }

  async function askFree() {
    if (!q.trim()) return;
    setAnswer(""); setLoading(true); setErr(null);
    try {
      const r = await fetch(`${API_BASE}/api/v1/ai/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: q.trim(), user_id: 1 }),
      });
      const js = await r.json();
      const reply = js?.reply || "Sem resposta.";
      setAnswer(reply);
      beepOk();
    } catch (e: any) {
      setErr(e?.message || "Falha ao consultar IA");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadSummary(); }, []);

  return (
    <div className="ai-card" role="region" aria-label="Resumo IA • Aurea Gold" style={{marginBottom: 12}}>
      <div className="ai-head" style={{display:"flex", alignItems:"center", gap:8}}>
        <strong>IA • Aurea Gold</strong>
        <button onClick={loadSummary} disabled={loading} className="btn" style={{marginLeft:"auto"}}>
          Atualizar
        </button>
      </div>

      {err && <div className="ai-err" role="alert" style={{marginTop: 8}}>Erro: {err}</div>}

      {loading && <div className="ai-load" style={{opacity:.8, marginTop:8}}>Carregando…</div>}

      {!!data && !loading && (
        <div className="ai-grid"
          style={{display:"grid", gridTemplateColumns:"repeat(4, minmax(0,1fr))", gap:8, marginTop:8}}>
          <div className="ai-kpi">
            <div className="ai-kpi-label">Saldo atual</div>
            <div className="ai-kpi-value">R$ {data.saldo_atual.toFixed(2)}</div>
          </div>
          <div className="ai-kpi">
            <div className="ai-kpi-label">Entradas totais</div>
            <div className="ai-kpi-value">R$ {data.entradas_total.toFixed(2)}</div>
          </div>
          <div className="ai-kpi">
            <div className="ai-kpi-label">Saídas totais</div>
            <div className="ai-kpi-value">R$ {data.saidas_total.toFixed(2)}</div>
          </div>
          <div className="ai-kpi">
            <div className="ai-kpi-label">Últimas 24h</div>
            <div className="ai-kpi-value">
              +{data.ultimas_24h.entradas.toFixed(2)} / -{data.ultimas_24h.saidas.toFixed(2)} ({data.ultimas_24h.qtd} trans.)
            </div>
          </div>
        </div>
      )}

      <div className="ai-free" style={{display:"flex", gap:8, marginTop:12}}>
        <input
          className="ai-input"
          placeholder="Pergunte algo sobre seu PIX (ex.: 'resumo de hoje')"
          value={q}
          onChange={(e)=>setQ(e.target.value)}
          style={{flex:1, padding:8, border:"1px solid #333", borderRadius:8, background:"#111", color:"#eee"}}
        />
        <button onClick={askFree} disabled={loading} className="btn">Perguntar</button>
      </div>

      {answer && <div className="ai-answer" style={{marginTop:10}}><strong>IA:</strong> {answer}</div>}

      <style>{`
        .ai-card{border:1px solid #2b2b2b; border-radius:14px; padding:12px; background:linear-gradient(180deg,#0c0c0c,#121212);}
        .btn{border:1px solid #414141; background:#171717; padding:6px 10px; border-radius:10px; cursor:pointer}
        .btn:disabled{opacity:.6; cursor:not-allowed}
        .ai-kpi{border:1px solid #2b2b2b; border-radius:12px; padding:10px; background:#0f0f0f}
        .ai-kpi-label{font-size:12px; opacity:.7; margin-bottom:4px}
        .ai-kpi-value{font-size:18px}
        .ai-err{color:#ff6961}
      `}</style>
    </div>
  );
}
