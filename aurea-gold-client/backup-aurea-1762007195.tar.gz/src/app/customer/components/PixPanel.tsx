<div className="pix-ai-wrap">


    <div className="pix-ai-wrap">



      <div className="pix-ai-wrap">




        <PixAISummary />




        <p>Saldo em PIX: {saldo !== null ? fmtBR(saldo) : "--"}</p>




      </div>



    </div>


  </div>


      {hist.length > 0 ? (
        hist.map(it => (
          <div key={it.id} className={"pix-item " + it.tipo}>
            <span>{it.tipo}</span>
            <span>{fmtBR(it.valor, it.tipo)}</span>
            <span>{it.descricao}</span>
          </div>
        ))
      ) : (
        <p>Nenhuma movimentao.</p>
      )}

      {showModal && <PixModal onClose={() => setShowModal(false)} onConfirm={onConfirmPix} />}
      {toast && <Toast kind={toast.kind} onClose={() => setToast(null)}>{toast.msg}</Toast>}

    </div>
  );
</div>
}

export default PixPanel;
